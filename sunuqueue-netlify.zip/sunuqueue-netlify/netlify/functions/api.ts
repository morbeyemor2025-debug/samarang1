import type { Handler, HandlerEvent } from "@netlify/functions";

// ─── Upstash Redis Client (HTTP — pas de driver TCP) ─────────────────────────
// Variables d'env à configurer sur Netlify :
//   UPSTASH_REDIS_REST_URL  → ex: https://us1-xxx.upstash.io
//   UPSTASH_REDIS_REST_TOKEN → ex: AXXXxxxxxxxx

const REDIS_URL = process.env.UPSTASH_REDIS_REST_URL || "";
const REDIS_TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN || "";

async function redis(cmd: unknown[]): Promise<unknown> {
  const res = await fetch(`${REDIS_URL}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${REDIS_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(cmd),
  });
  const data = (await res.json()) as { result: unknown; error?: string };
  if (data.error) throw new Error(data.error);
  return data.result;
}

// Helpers Redis
async function getJSON<T>(key: string): Promise<T | null> {
  const val = (await redis(["GET", key])) as string | null;
  return val ? (JSON.parse(val) as T) : null;
}
async function setJSON(key: string, value: unknown, exSeconds = 86400) {
  await redis(["SET", key, JSON.stringify(value), "EX", exSeconds]);
}

// ─── Types ────────────────────────────────────────────────────────────────────
interface Client {
  id: string;
  name: string;
  phone: string;
  position: number;
  joinedAt: string;
  status: "waiting" | "called" | "done";
}

interface Salon {
  id: string;
  name: string;
  queue: Client[];
}

// Salons de démo (créés à la volée si inexistants)
const DEMO_SALONS: Record<string, string> = {
  "salon-demo": "Salon Teranga Beauté",
  "salon-alpha": "Salon Alpha Coiffure",
};

function nanoid(size = 8): string {
  return Math.random().toString(36).slice(2, 2 + size);
}

async function getSalon(id: string): Promise<Salon> {
  let salon = await getJSON<Salon>(`salon:${id}`);
  if (!salon) {
    salon = {
      id,
      name: DEMO_SALONS[id] || `Salon ${id}`,
      queue: [],
    };
    await setJSON(`salon:${id}`, salon);
  }
  return salon;
}

async function saveSalon(salon: Salon) {
  await setJSON(`salon:${salon.id}`, salon);
}

function buildWhatsappJoin(client: Client, salon: Salon): string {
  const msg = encodeURIComponent(
    `✅ Vous êtes inscrit chez ${salon.name} !\n\n` +
      `📍 Votre position : N°${client.position}\n` +
      `⏱ Temps estimé : ~${client.position * 20} minutes\n\n` +
      `Vous recevrez un message quand c'est votre tour.`
  );
  return `https://wa.me/${client.phone}?text=${msg}`;
}

function buildWhatsappCall(client: Client, salon: Salon): string {
  const msg = encodeURIComponent(
    `🔔 C'est votre tour !\n\n` +
      `${client.name}, veuillez vous présenter au ${salon.name} dans les 5 prochaines minutes.\n\nMerci ! 🙏`
  );
  return `https://wa.me/${client.phone}?text=${msg}`;
}

function json(statusCode: number, body: unknown) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
    body: JSON.stringify(body),
  };
}

// ─── Router ───────────────────────────────────────────────────────────────────
export const handler: Handler = async (event: HandlerEvent) => {
  // CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
      body: "",
    };
  }

  const path = event.path.replace(/^\/.netlify\/functions\/api/, "").replace(/^\/api/, "");
  const method = event.httpMethod;
  const segments = path.split("/").filter(Boolean);
  const body = event.body ? JSON.parse(event.body) : {};

  try {
    // GET /health
    if (method === "GET" && path === "/health") {
      return json(200, { status: "ok", ts: new Date().toISOString() });
    }

    // GET /salons/:id
    if (method === "GET" && segments[0] === "salons" && segments.length === 2) {
      const salon = await getSalon(segments[1]);
      const waiting = salon.queue.filter((c) => c.status === "waiting");
      return json(200, {
        id: salon.id,
        name: salon.name,
        waitingCount: waiting.length,
        estimatedWait: waiting.length * 20,
        queue: salon.queue.map((c) => ({
          id: c.id,
          name: c.name,
          position: c.position,
          status: c.status,
          joinedAt: c.joinedAt,
        })),
      });
    }

    // POST /salons/:id/join
    if (method === "POST" && segments[0] === "salons" && segments[2] === "join") {
      const salon = await getSalon(segments[1]);
      const { name, phone } = body as { name: string; phone: string };
      if (!name) return json(400, { error: "Nom requis" });

      const existing = salon.queue.find((c) => c.phone === phone && c.status === "waiting" && phone);
      if (existing) return json(200, { client: existing, salon: { name: salon.name }, alreadyInQueue: true });

      const waiting = salon.queue.filter((c) => c.status === "waiting");
      const client: Client = {
        id: nanoid(),
        name: name.trim(),
        phone: (phone || "").replace(/\D/g, ""),
        position: waiting.length + 1,
        joinedAt: new Date().toISOString(),
        status: "waiting",
      };
      salon.queue.push(client);
      await saveSalon(salon);

      return json(200, {
        client: { id: client.id, name: client.name, position: client.position, estimatedWait: client.position * 20 },
        salon: { name: salon.name },
        whatsappLink: client.phone ? buildWhatsappJoin(client, salon) : null,
      });
    }

    // GET /salons/:id/client/:clientId
    if (method === "GET" && segments[0] === "salons" && segments[2] === "client") {
      const salon = await getSalon(segments[1]);
      const client = salon.queue.find((c) => c.id === segments[3]);
      if (!client) return json(404, { error: "Client introuvable" });

      const waiting = salon.queue.filter((c) => c.status === "waiting");
      const pos = waiting.findIndex((c) => c.id === client.id) + 1;

      return json(200, {
        id: client.id,
        name: client.name,
        position: pos > 0 ? pos : null,
        status: client.status,
        estimatedWait: pos > 0 ? pos * 20 : 0,
        salonName: salon.name,
        queue: waiting.slice(0, 6).map((c, i) => ({
          id: c.id,
          name: c.name.split(" ")[0],
          position: i + 1,
        })),
      });
    }

    // POST /salons/:id/next
    if (method === "POST" && segments[0] === "salons" && segments[2] === "next") {
      const salon = await getSalon(segments[1]);
      const waiting = salon.queue.filter((c) => c.status === "waiting");
      if (waiting.length === 0) return json(200, { message: "File vide", called: null });

      const next = waiting[0];
      const idx = salon.queue.findIndex((c) => c.id === next.id);
      salon.queue[idx].status = "called";

      // Renuméroter
      let pos = 1;
      salon.queue.forEach((c) => { if (c.status === "waiting") c.position = pos++; });

      await saveSalon(salon);

      const stillWaiting = salon.queue.filter((c) => c.status === "waiting");
      return json(200, {
        called: { id: next.id, name: next.name, phone: next.phone },
        whatsappLink: next.phone ? buildWhatsappCall(next, salon) : null,
        remaining: stillWaiting.length,
      });
    }

    // POST /salons/:id/done/:clientId
    if (method === "POST" && segments[0] === "salons" && segments[2] === "done") {
      const salon = await getSalon(segments[1]);
      const idx = salon.queue.findIndex((c) => c.id === segments[3]);
      if (idx === -1) return json(404, { error: "Client introuvable" });
      salon.queue[idx].status = "done";
      await saveSalon(salon);
      return json(200, { ok: true });
    }

    // POST /salons/:id/remove/:clientId
    if (method === "POST" && segments[0] === "salons" && segments[2] === "remove") {
      const salon = await getSalon(segments[1]);
      salon.queue = salon.queue.filter((c) => c.id !== segments[3]);
      let pos = 1;
      salon.queue.forEach((c) => { if (c.status === "waiting") c.position = pos++; });
      await saveSalon(salon);
      return json(200, { ok: true });
    }

    // POST /salons/:id/add
    if (method === "POST" && segments[0] === "salons" && segments[2] === "add") {
      const salon = await getSalon(segments[1]);
      const { name, phone } = body as { name: string; phone?: string };
      if (!name) return json(400, { error: "Nom requis" });

      const waiting = salon.queue.filter((c) => c.status === "waiting");
      const client: Client = {
        id: nanoid(),
        name: name.trim(),
        phone: (phone || "").replace(/\D/g, ""),
        position: waiting.length + 1,
        joinedAt: new Date().toISOString(),
        status: "waiting",
      };
      salon.queue.push(client);
      await saveSalon(salon);
      return json(200, { client });
    }

    // GET /stats/:id
    if (method === "GET" && segments[0] === "stats") {
      const salon = await getSalon(segments[1]);
      const q = salon.queue;
      return json(200, {
        totalToday: q.length,
        served: q.filter((c) => c.status === "done").length,
        waiting: q.filter((c) => c.status === "waiting").length,
        called: q.filter((c) => c.status === "called").length,
        avgWait: 20,
      });
    }

    return json(404, { error: "Route introuvable" });
  } catch (err) {
    console.error("API error:", err);
    return json(500, { error: "Erreur serveur" });
  }
};
