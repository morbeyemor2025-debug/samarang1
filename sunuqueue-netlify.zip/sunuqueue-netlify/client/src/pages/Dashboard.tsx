import { useState, useEffect, useRef } from "react";
import { useParams } from "wouter";
import { toast } from "sonner";

interface QueueClient {
  id: string;
  name: string;
  position: number;
  status: "waiting" | "called" | "done";
  joinedAt: string;
}

interface Stats {
  totalToday: number;
  served: number;
  waiting: number;
  called: number;
  avgWait: number;
}

interface Salon {
  id: string;
  name: string;
  queue: QueueClient[];
  waitingCount: number;
}

export default function Dashboard() {
  const { salonId } = useParams<{ salonId: string }>();
  const [salon, setSalon] = useState<Salon | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [calling, setCalling] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [addName, setAddName] = useState("");
  const [addPhone, setAddPhone] = useState("");
  const [lastCalled, setLastCalled] = useState<{ name: string; whatsappLink: string } | null>(null);
  const eventSourceRef = useRef<EventSource | null>(null);

  async function fetchSalon() {
    const [salonRes, statsRes] = await Promise.all([
      fetch(`/api/salons/${salonId}`),
      fetch(`/api/stats/${salonId}`),
    ]);
    const salonData = await salonRes.json();
    const statsData = await statsRes.json();
    setSalon(salonData);
    setStats(statsData);
    setLoading(false);
  }

  useEffect(() => {
    fetchSalon();

    const es = new EventSource(`/api/salons/${salonId}/events`);
    eventSourceRef.current = es;
    es.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (["init", "queue_update", "client_called"].includes(data.type)) {
        fetchSalon();
      }
    };

    return () => { es.close(); };
  }, [salonId]);

  async function callNext() {
    setCalling(true);
    try {
      const res = await fetch(`/api/salons/${salonId}/next`, { method: "POST" });
      const data = await res.json();
      if (data.called) {
        setLastCalled({ name: data.called.name, whatsappLink: data.whatsappLink });
        toast.success(`${data.called.name} a été appelé !`);
      } else {
        toast.info("La file est vide !");
      }
      await fetchSalon();
    } catch {
      toast.error("Erreur lors de l'appel");
    } finally {
      setCalling(false);
    }
  }

  async function markDone(clientId: string, name: string) {
    await fetch(`/api/salons/${salonId}/done/${clientId}`, { method: "POST" });
    toast.success(`${name} marqué comme servi ✓`);
    await fetchSalon();
  }

  async function removeClient(clientId: string, name: string) {
    await fetch(`/api/salons/${salonId}/remove/${clientId}`, { method: "POST" });
    toast.info(`${name} retiré de la file`);
    await fetchSalon();
  }

  async function addManual(e: React.FormEvent) {
    e.preventDefault();
    if (!addName.trim()) return;
    try {
      await fetch(`/api/salons/${salonId}/add`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: addName.trim(), phone: addPhone }),
      });
      toast.success(`${addName} ajouté à la file`);
      setAddName(""); setAddPhone(""); setShowAddModal(false);
      await fetchSalon();
    } catch {
      toast.error("Erreur lors de l'ajout");
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-gray-500 text-sm">Chargement...</p>
        </div>
      </div>
    );
  }

  const waiting = salon?.queue.filter(c => c.status === "waiting") || [];
  const calledClients = salon?.queue.filter(c => c.status === "called") || [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top bar */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">S</span>
            </div>
            <div>
              <div className="font-bold text-gray-900 text-sm leading-tight">{salon?.name}</div>
              <div className="text-xs text-gray-500 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full inline-block animate-pulse" />
                En ligne
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={`/join/${salonId}`}
              target="_blank"
              className="text-xs bg-blue-50 text-blue-700 px-3 py-1.5 rounded-full font-medium border border-blue-100 hover:bg-blue-100 transition"
            >
              📱 QR Page
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-5 space-y-4">

        {/* Stats rapides */}
        {stats && (
          <div className="grid grid-cols-4 gap-2">
            {[
              { label: "Aujourd'hui", value: stats.totalToday, color: "text-gray-900" },
              { label: "En attente", value: stats.waiting, color: "text-blue-600" },
              { label: "Servis", value: stats.served, color: "text-green-600" },
              { label: "Moy. (min)", value: stats.avgWait, color: "text-amber-600" },
            ].map((s) => (
              <div key={s.label} className="bg-white rounded-xl border border-gray-100 p-3 text-center">
                <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
                <div className="text-xs text-gray-400 mt-0.5 leading-tight">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        {/* BOUTON PRINCIPAL — Appeler le suivant */}
        <button
          onClick={callNext}
          disabled={calling || waiting.length === 0}
          className={`w-full py-6 rounded-2xl text-xl font-bold transition-all active:scale-95 shadow-sm ${
            waiting.length === 0
              ? "bg-gray-100 text-gray-400 cursor-not-allowed"
              : "bg-blue-600 hover:bg-blue-700 text-white shadow-blue-200"
          }`}
        >
          {calling ? (
            <span className="flex items-center justify-center gap-3">
              <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
              Appel en cours...
            </span>
          ) : waiting.length === 0 ? (
            "✅ File vide"
          ) : (
            <span className="flex flex-col items-center">
              <span>🔔 Appeler le suivant</span>
              <span className="text-sm font-normal opacity-80 mt-1">
                {waiting.length} client{waiting.length > 1 ? "s" : ""} en attente · {waiting[0]?.name}
              </span>
            </span>
          )}
        </button>

        {/* WhatsApp du dernier appelé */}
        {lastCalled && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-green-800">🔔 {lastCalled.name} appelé !</p>
              <p className="text-xs text-green-600 mt-0.5">Notifier via WhatsApp ?</p>
            </div>
            <a
              href={lastCalled.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setLastCalled(null)}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded-xl transition"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              Envoyer
            </a>
          </div>
        )}

        {/* Clients en cours (appelés) */}
        {calledClients.length > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
            <h3 className="text-sm font-semibold text-amber-700 mb-3 flex items-center gap-2">
              <span className="w-2 h-2 bg-amber-400 rounded-full animate-pulse inline-block" />
              En cours de service
            </h3>
            <div className="space-y-2">
              {calledClients.map(c => (
                <div key={c.id} className="flex items-center gap-3 bg-white rounded-xl p-3 border border-amber-100">
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900 text-sm">{c.name}</p>
                  </div>
                  <button
                    onClick={() => markDone(c.id, c.name)}
                    className="text-xs bg-green-600 text-white px-3 py-1.5 rounded-lg font-medium hover:bg-green-700 transition"
                  >
                    ✓ Terminé
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* File d'attente */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
            <h3 className="font-semibold text-gray-800 text-sm flex items-center gap-2">
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse inline-block" />
              File d'attente ({waiting.length})
            </h3>
            <button
              onClick={() => setShowAddModal(true)}
              className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded-full font-medium transition"
            >
              + Ajouter manuellement
            </button>
          </div>

          {waiting.length === 0 ? (
            <div className="py-10 text-center text-gray-400">
              <div className="text-4xl mb-3">🎉</div>
              <p className="text-sm">La file est vide !</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {waiting.map((client, idx) => (
                <div key={client.id} className={`flex items-center gap-3 px-4 py-3 transition-colors ${idx === 0 ? "bg-blue-50" : "hover:bg-gray-50"}`}>
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 ${idx === 0 ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600"}`}>
                    {client.position}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`font-semibold text-sm truncate ${idx === 0 ? "text-blue-900" : "text-gray-900"}`}>
                      {client.name}
                      {idx === 0 && <span className="ml-2 text-xs bg-blue-200 text-blue-800 px-2 py-0.5 rounded-full font-medium">Prochain</span>}
                    </p>
                    <p className="text-xs text-gray-400">
                      {new Date(client.joinedAt).toLocaleTimeString("fr-SN", { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => removeClient(client.id, client.name)}
                      className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition text-lg"
                      title="Retirer"
                    >
                      ×
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Lien QR Code */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-4 text-white text-center">
          <p className="text-sm font-semibold mb-1">📲 Lien QR Code pour votre salon</p>
          <p className="text-xs opacity-80 mb-3 font-mono break-all">
            {window.location.origin}/join/{salonId}
          </p>
          <button
            onClick={() => {
              navigator.clipboard.writeText(`${window.location.origin}/join/${salonId}`);
              toast.success("Lien copié !");
            }}
            className="bg-white/20 hover:bg-white/30 text-white text-xs px-4 py-2 rounded-lg font-medium transition"
          >
            📋 Copier le lien
          </button>
        </div>
      </div>

      {/* Modal ajout manuel */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Ajouter un client</h3>
            <form onSubmit={addManual} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Prénom *</label>
                <input
                  type="text"
                  value={addName}
                  onChange={e => setAddName(e.target.value)}
                  placeholder="Amadou"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-base focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">WhatsApp (optionnel)</label>
                <input
                  type="tel"
                  value={addPhone}
                  onChange={e => setAddPhone(e.target.value)}
                  placeholder="221 77 000 00 00"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-base focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => { setShowAddModal(false); setAddName(""); setAddPhone(""); }}
                  className="flex-1 py-3 rounded-xl border border-gray-200 text-gray-700 font-semibold text-base hover:bg-gray-50 transition"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-base transition"
                >
                  Ajouter
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
