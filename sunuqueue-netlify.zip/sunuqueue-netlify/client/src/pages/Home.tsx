import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle, Smartphone, Users, MessageCircle, BarChart3, Zap, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-gray-100">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">S</span>
            </div>
            <span className="font-bold text-xl text-gray-900">SunuQueue</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#how" className="text-gray-600 hover:text-blue-600 transition text-sm">Comment ça marche</a>
            <a href="#features" className="text-gray-600 hover:text-blue-600 transition text-sm">Fonctionnalités</a>
            <a href="#pricing" className="text-gray-600 hover:text-blue-600 transition text-sm">Tarifs</a>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              className="border-blue-600 text-blue-600 hover:bg-blue-50 text-sm"
              onClick={() => navigate("/dashboard/salon-demo")}
            >
              Démo coiffeur
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700 text-sm" onClick={() => navigate("/join/salon-demo")}>
              Essayer
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-amber-50">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23007BFF' fill-opacity='0.6'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }} />
        <div className="container relative z-10 py-20 md:py-28">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 text-xs font-semibold px-3 py-1.5 rounded-full mb-6">
                🇸🇳 Conçu pour le Sénégal
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
                Plus de clients debout à attendre dans votre salon
              </h1>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Vos clients scannent un QR code, attendent confortablement où ils veulent, et reçoivent une notification WhatsApp quand c'est leur tour.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 mb-8">
                <Button
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
                  onClick={() => navigate("/join/salon-demo")}
                >
                  Voir la démo client <ArrowRight className="w-4 h-4" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-gray-300 text-gray-700 gap-2"
                  onClick={() => navigate("/dashboard/salon-demo")}
                >
                  Interface coiffeur
                </Button>
              </div>
              <div className="flex items-center gap-4 text-sm text-gray-500">
                <div className="flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  Gratuit pour démarrer
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  Pas d'app à télécharger
                </div>
              </div>
            </div>
            <div className="flex justify-center">
              <div className="relative">
                {/* Mock phone screen */}
                <div className="w-64 bg-white rounded-3xl shadow-2xl border-4 border-gray-800 overflow-hidden">
                  <div className="bg-gray-800 h-6 flex items-center justify-center">
                    <div className="w-16 h-1.5 bg-gray-600 rounded-full" />
                  </div>
                  <div className="bg-gradient-to-b from-blue-50 to-white p-4">
                    <div className="text-center mb-4">
                      <div className="w-10 h-10 bg-blue-600 rounded-xl mx-auto mb-2 flex items-center justify-center">
                        <span className="text-white font-bold">S</span>
                      </div>
                      <p className="text-xs font-bold text-gray-900">Salon Teranga Beauté</p>
                    </div>
                    <div className="flex justify-center gap-6 mb-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">3</div>
                        <div className="text-xs text-gray-500">en attente</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-amber-500">~60</div>
                        <div className="text-xs text-gray-500">minutes</div>
                      </div>
                    </div>
                    {/* Position badge */}
                    <div className="bg-white rounded-2xl p-3 shadow-sm text-center mb-3">
                      <p className="text-xs text-gray-500 mb-1">Votre position</p>
                      <div className="w-14 h-14 rounded-full bg-blue-50 border-4 border-blue-200 flex items-center justify-center mx-auto mb-1">
                        <span className="text-2xl font-bold text-blue-600">2</span>
                      </div>
                      <p className="text-xs font-semibold text-gray-800">Bonjour Moussa 👋</p>
                    </div>
                    {/* Queue preview */}
                    <div className="space-y-1.5">
                      {[{n:"Fatou", p:1,me:false},{n:"Moussa",p:2,me:true},{n:"Ibou",p:3,me:false}].map(c=>(
                        <div key={c.n} className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs ${c.me ? "bg-blue-50 border border-blue-200" : "bg-gray-50"}`}>
                          <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold flex-shrink-0 ${c.p===1?"bg-amber-400 text-white":"bg-gray-200 text-gray-600"}`}>{c.p}</span>
                          <span className={c.me?"text-blue-700 font-semibold":"text-gray-700"}>{c.n}{c.me?" (vous)":""}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                {/* WhatsApp notification bubble */}
                <div className="absolute -right-4 top-1/3 bg-white rounded-2xl shadow-lg p-3 w-44 border border-gray-100 animate-bounce-slow">
                  <div className="flex items-start gap-2">
                    <div className="w-7 h-7 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-800">🔔 C'est votre tour !</p>
                      <p className="text-xs text-gray-500 mt-0.5">Présentez-vous dans 5 min.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">Comment ça marche ?</h2>
            <p className="text-gray-500 text-lg">3 étapes. Zéro complication.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              {
                step: "1",
                emoji: "📲",
                title: "Le client scanne",
                desc: "Un QR code plastifié à l'entrée du salon. Le client ouvre une page web directement — aucune application à télécharger.",
                color: "bg-blue-50 text-blue-600",
              },
              {
                step: "2",
                emoji: "🛋️",
                title: "Il attend où il veut",
                desc: "Il voit sa position en temps réel sur son téléphone. Il peut aller faire des courses, prendre un café, rentrer chez lui.",
                color: "bg-amber-50 text-amber-600",
              },
              {
                step: "3",
                emoji: "🔔",
                title: "Notification WhatsApp",
                desc: "Quand le coiffeur appuie sur le bouton, le client reçoit un message WhatsApp : \"C'est votre tour !\"",
                color: "bg-green-50 text-green-600",
              },
            ].map((s) => (
              <div key={s.step} className="text-center relative">
                <div className={`w-16 h-16 ${s.color} rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4`}>
                  {s.emoji}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{s.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Button size="lg" onClick={() => navigate("/join/salon-demo")} className="bg-blue-600 hover:bg-blue-700 gap-2">
              Tester maintenant — démo interactive <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">Pourquoi SunuQueue ?</h2>
            <p className="text-gray-500">Une solution simple, efficace et adaptée au Sénégal</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: <Smartphone className="w-6 h-6" />, title: "Zéro Installation", desc: "Pas d'app à télécharger. Les clients accèdent via un simple lien web après scan QR." },
              { icon: <MessageCircle className="w-6 h-6" />, title: "WhatsApp Natif", desc: "Les notifications arrivent directement sur WhatsApp, le canal numéro 1 au Sénégal." },
              { icon: <Users className="w-6 h-6" />, title: "Interface coiffeur simple", desc: "Un seul bouton pour appeler le suivant. Gros boutons tactiles, conçus pour les salons." },
              { icon: <BarChart3 className="w-6 h-6" />, title: "Stats en temps réel", desc: "Suivez le flux de clients, les heures de pointe et le temps d'attente moyen." },
              { icon: <Zap className="w-6 h-6" />, title: "Wave & Orange Money", desc: "Payez votre abonnement directement via mobile money. Pas de carte bancaire nécessaire." },
              { icon: <CheckCircle className="w-6 h-6" />, title: "Fonctionne hors ligne", desc: "Progressive Web App : le coiffeur peut gérer la file même avec une connexion lente." },
            ].map((f, i) => (
              <Card key={i} className="p-5 hover:shadow-md transition">
                <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-3">{f.icon}</div>
                <h3 className="font-bold text-gray-900 mb-1.5">{f.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{f.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">Tarifs simples</h2>
            <p className="text-gray-500">Adaptés aux salons sénégalais</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { name: "Ndiagua", sub: "Gratuit", price: "0", features: ["30 clients/mois", "Notifications WhatsApp", "Interface coiffeur", "Support email"], cta: "Démarrer", highlight: false },
              { name: "Téranga", sub: "Standard", price: "10 000", features: ["Clients illimités", "WhatsApp personnalisé", "Dashboard complet", "Stats de base", "Support WhatsApp"], cta: "Commencer", highlight: true },
              { name: "Grand Salon", sub: "Pro", price: "25 000", features: ["Multi-coiffeurs", "Statistiques avancées", "Export données", "Support prioritaire 24/7", "Intégration Wave/OM"], cta: "Contacter", highlight: false },
            ].map((p, i) => (
              <Card key={i} className={`p-6 flex flex-col relative ${p.highlight ? "border-2 border-blue-600 shadow-lg" : ""}`}>
                {p.highlight && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-bold px-4 py-1 rounded-full">
                    Le plus populaire
                  </div>
                )}
                <div className="mb-4">
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">{p.sub}</p>
                  <h3 className="text-xl font-bold text-gray-900 mt-0.5">{p.name}</h3>
                  <div className="mt-2 flex items-baseline gap-1">
                    <span className="text-3xl font-bold text-blue-600">{p.price}</span>
                    <span className="text-gray-500 text-sm">FCFA/mois</span>
                  </div>
                </div>
                <ul className="space-y-2 mb-6 flex-grow">
                  {p.features.map((f, fi) => (
                    <li key={fi} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Button variant={p.highlight ? "default" : "outline"} className={`w-full ${p.highlight ? "bg-blue-600 hover:bg-blue-700" : "border-blue-600 text-blue-600 hover:bg-blue-50"}`}>
                  {p.cta}
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-700">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Prêt à transformer votre salon ?</h2>
          <p className="text-blue-100 text-lg mb-8 max-w-xl mx-auto">
            Testez la démo complète maintenant — côté client et côté coiffeur.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button size="lg" className="bg-amber-400 hover:bg-amber-500 text-amber-900 font-bold gap-2" onClick={() => navigate("/join/salon-demo")}>
              📱 Démo client <ArrowRight className="w-4 h-4" />
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10" onClick={() => navigate("/dashboard/salon-demo")}>
              💈 Démo coiffeur
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-10">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">S</span>
              </div>
              <span className="font-bold text-white">SunuQueue</span>
              <span className="text-gray-600 text-sm ml-2">La file d'attente intelligente pour salons au Sénégal.</span>
            </div>
            <p className="text-sm">© 2026 SunuQueue · Tous droits réservés</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
